:mod:`certbot_dns_route53.dns_route53`
--------------------------------------

.. automodule:: certbot_dns_route53.dns_route53
   :members:
