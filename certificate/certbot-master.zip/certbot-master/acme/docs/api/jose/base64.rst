JOSE Base64
-----------

.. automodule:: acme.jose.b64
   :members:
