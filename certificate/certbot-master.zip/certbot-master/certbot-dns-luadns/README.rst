LuaDNS Authenticator plugin for Certbot
